My sudoku solving algorithm is based on backtracking.
Before checking for backtracking my program checks to see if the sudoku is valid and only then will backtracking occur.
My program will simply revert back to the previous step or solution as soon as it determines that the current solution cannot be continued into a complete one.
